namespace ScreenTask.Core.Streaming
{
    public enum VideoEncodingFormat
    {
        Jpeg,
        WebP
    }
}
