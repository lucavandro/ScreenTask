using System.Buffers;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using ImageMagick;
using ImageMagick.Formats;

namespace ScreenTask.Core.Streaming
{
    internal static class WebPFrameEncoder
    {
        static WebPFrameEncoder()
        {
            // Image pixels must stay in memory; never spill the pixel cache to disk.
            ResourceLimits.Disk = 0;
        }

        public static byte[] EncodePacket(Bitmap bitmap, int quality)
        {
            int rowLength = checked(bitmap.Width * 4);
            int length = checked(rowLength * bitmap.Height);
            var buffer = ArrayPool<byte>.Shared.Rent(length);
            try
            {
                var bounds = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
                var pixels = bitmap.LockBits(bounds, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                try
                {
                    if (pixels.Stride == rowLength)
                        Marshal.Copy(pixels.Scan0, buffer, 0, length);
                    else
                        for (int y = 0; y < bitmap.Height; y++)
                            Marshal.Copy(IntPtr.Add(pixels.Scan0, y * pixels.Stride), buffer, y * rowLength, rowLength);
                }
                finally
                {
                    bitmap.UnlockBits(pixels);
                }
                using var image = new MagickImage();
                image.ReadPixels(buffer, 0, (uint)length,
                    new PixelReadSettings((uint)bitmap.Width, (uint)bitmap.Height, StorageType.Char, PixelMapping.BGRA));
                image.Alpha(AlphaAction.Off);
                image.Quality = (uint)Math.Clamp(quality, 10, 100);
                image.Settings.SetDefines(new WebPWriteDefines
                {
                    Method = 0, Lossless = false, ThreadLevel = true, UseSharpYuv = false, Pass = 1
                });
                var encoded = image.ToByteArray(MagickFormat.WebP);
                var packet = new byte[encoded.Length + 1];
                packet[0] = 0x05;
                encoded.CopyTo(packet, 1);
                return packet;
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(buffer);
            }
        }

        public static byte[] ToJpeg(byte[] webpPacket)
        {
            using var image = new MagickImage(webpPacket, 1, (uint)webpPacket.Length - 1, MagickFormat.WebP);
            image.Quality = 90;
            return image.ToByteArray(MagickFormat.Jpeg);
        }
    }
}
