using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Text.Json;
using ScreenTask.Core.Streaming;

var output = Path.GetFullPath(".ecc/benchmarks");
Directory.CreateDirectory(output);
Directory.CreateDirectory(Path.GetFullPath("build/webp-comparison"));
var results = new List<object>();
var frames = new List<object>();
using var process = Process.GetCurrentProcess();
Console.WriteLine($"Machine: {Environment.ProcessorCount} logical processors, .NET {Environment.Version}, {RuntimeInformation.OSDescription}; Release, synthetic frames only");
foreach (var size in new[] { new Size(1280, 720), new Size(1920, 1080), new Size(3840, 2160) })
foreach (string scene in new[] { "slide", "code", "photo-like" })
{
    using var bitmap = MakeScene(size, scene);
    foreach (int quality in new[] { 60, 75, 90 })
    {
        var configs = new[] { (Format: VideoEncodingFormat.Jpeg, Modern: true, Legacy: false, Name: "JPEG"),
                              (Format: VideoEncodingFormat.WebP, Modern: true, Legacy: false, Name: "WebP") };
        var measurements = configs.ToDictionary(c => c.Name, c => new Measurement());
        // Alternate codec order across three rounds; avoid one long warm/cold codec block.
        for (int round = 0; round < 3; round++)
        foreach (var config in round % 2 == 0 ? configs : configs.Reverse())
        {
            using var broadcaster = new StreamBroadcaster(quality) { VideoFormat = config.Format };
            using var socket = new SinkSocket();
            broadcaster.AddVideoClient("modern", socket, supportsWebP: config.Modern);
            for (int i = 0; i < (round == 0 ? 5 : 2); i++) await broadcaster.BroadcastBitmapAsync(bitmap);
            var m = measurements[config.Name];
            var cpu = process.TotalProcessorTime;
            long allocations = GC.GetTotalAllocatedBytes(true);
            for (int sample = 0; sample < 10; sample++)
            {
                long started = Stopwatch.GetTimestamp();
                await broadcaster.BroadcastBitmapAsync(bitmap);
                m.Times.Add(Stopwatch.GetElapsedTime(started).TotalMilliseconds);
            }
            m.Allocations += GC.GetTotalAllocatedBytes(true) - allocations;
            m.CpuMs += (process.TotalProcessorTime - cpu).TotalMilliseconds;
            m.Bytes = socket.Packet.Length;
            if (size.Width == 1920 && quality == 75 && round == 0)
                frames.Add(new { scene, codec = config.Name, mime = config.Name == "WebP" ? "image/webp" : "image/jpeg", data = Convert.ToBase64String(socket.Packet.AsSpan(1)) });
        }
        foreach (var config in configs)
        {
            var m = measurements[config.Name];
            var sorted = m.Times.Order().ToArray();
            results.Add(new { scene, width = size.Width, height = size.Height, quality, codec = config.Name, samples = sorted.Length,
                p50Ms = Percentile(sorted, .5), p95Ms = Percentile(sorted, .95), p99Ms = Percentile(sorted, .99),
                packetBytes = m.Bytes, managedBytesPerFrame = m.Allocations / sorted.Length, cpuMsPerFrame = m.CpuMs / sorted.Length,
                samplesMs = m.Times });
        }
        Console.WriteLine($"{size.Width}x{size.Height} {scene} q{quality}: JPEG p50={Percentile(measurements["JPEG"].Times.Order().ToArray(), .5):F1}ms; WebP p50={Percentile(measurements["WebP"].Times.Order().ToArray(), .5):F1}ms; bytes JPEG={measurements["JPEG"].Bytes} WebP={measurements["WebP"].Bytes}");
        await SaveResults();
    }
}

// Production broadcaster with a bounded, bandwidth-limited asynchronous sink.
// This models bandwidth without pretending to reproduce a Wi-Fi radio or phone decoder.
var throughput = new List<object>();
foreach (string scene in new[] { "slide", "code", "photo-like" })
foreach (int mbps in new[] { 10, 30, 100 })
foreach (var format in new[] { VideoEncodingFormat.Jpeg, VideoEncodingFormat.WebP })
{
    using var bitmap = MakeScene(new Size(1920, 1080), scene);
    using var broadcaster = new StreamBroadcaster(75) { VideoFormat = format };
    using var socket = new SinkSocket(mbps);
    broadcaster.AddVideoClient("modern", socket, supportsWebP: true);
    var timer = Stopwatch.StartNew();
    while (timer.Elapsed.TotalSeconds < 3)
    {
        long frameStart = Stopwatch.GetTimestamp();
        await broadcaster.BroadcastBitmapAsync(bitmap);
        // 30 FPS target with no capture cost: optimistic upper-bound host workload.
        double remaining = 1000.0 / 30 - Stopwatch.GetElapsedTime(frameStart).TotalMilliseconds;
        if (remaining > 0) await Task.Delay(TimeSpan.FromMilliseconds(remaining));
    }
    double elapsed = timer.Elapsed.TotalSeconds;
    long sent = broadcaster.TotalFramesSent;
    throughput.Add(new { scene, bandwidthMbps = mbps, codec = format.ToString(), elapsedSeconds = elapsed, sentFrames = sent,
        completedFps = sent / elapsed, droppedFrames = broadcaster.TotalFramesDropped });
    Console.WriteLine($"THROUGHPUT {scene} {mbps}Mbps {format}: {sent / elapsed:F2}FPS, drops={broadcaster.TotalFramesDropped}");
    await Task.Delay(200); // Let the last bounded send complete before disposing its socket.
}

var mixed = new List<object>();
foreach (var format in new[] { VideoEncodingFormat.Jpeg, VideoEncodingFormat.WebP })
{
    using var bitmap = MakeScene(new Size(1920, 1080), "code");
    using var broadcaster = new StreamBroadcaster(75) { VideoFormat = format };
    using var modern = new SinkSocket();
    using var legacy = new SinkSocket();
    broadcaster.AddVideoClient("modern", modern, supportsWebP: true);
    broadcaster.AddVideoClient("legacy", legacy);
    for (int i = 0; i < 5; i++) await broadcaster.BroadcastBitmapAsync(bitmap);
    var times = new List<double>();
    for (int i = 0; i < 30; i++)
    {
        long start = Stopwatch.GetTimestamp();
        await broadcaster.BroadcastBitmapAsync(bitmap);
        times.Add(Stopwatch.GetElapsedTime(start).TotalMilliseconds);
    }
    mixed.Add(new { codec = format.ToString(), p50Ms = Percentile(times.Order().ToArray(), .5), p95Ms = Percentile(times.Order().ToArray(), .95),
        modernPacketBytes = modern.Packet.Length, legacyPacketBytes = legacy.Packet.Length });
}
await File.WriteAllTextAsync(Path.Combine(output, "webp-throughput-2026-11-18.json"), JsonSerializer.Serialize(new { throughput, mixed }, new JsonSerializerOptions { WriteIndented = true }));
await File.WriteAllTextAsync(Path.GetFullPath("build/webp-comparison/frames.json"), JsonSerializer.Serialize(frames));
Console.WriteLine("DONE: encoding matrix, throughput, mixed audience and synthetic browser fixtures saved.");

async Task SaveResults() => await File.WriteAllTextAsync(Path.Combine(output, "webp-encoding-2026-11-18.json"), JsonSerializer.Serialize(new {
    environment = new { dotnet = Environment.Version.ToString(), os = RuntimeInformation.OSDescription, logicalProcessors = Environment.ProcessorCount, mode = "Release", warmupsFirstRound = 5, rounds = 3, samplesPerRound = 10 }, results
}, new JsonSerializerOptions { WriteIndented = true }));

static double Percentile(double[] sorted, double quantile) => sorted[Math.Clamp((int)Math.Ceiling(sorted.Length * quantile) - 1, 0, sorted.Length - 1)];

static Bitmap MakeScene(Size size, string scene)
{
    var bitmap = new Bitmap(size.Width, size.Height, PixelFormat.Format32bppArgb);
    using var graphics = Graphics.FromImage(bitmap);
    graphics.Clear(Color.FromArgb(245, 247, 250));
    if (scene == "photo-like")
    {
        var random = new Random(1729);
        var bytes = new byte[size.Width * size.Height * 4];
        for (int y = 0; y < size.Height; y++)
        for (int x = 0; x < size.Width; x++)
        {
            int p = (y * size.Width + x) * 4;
            bytes[p] = (byte)Math.Clamp(80 + 70 * Math.Sin(x * .013) + random.Next(-24, 25), 0, 255);
            bytes[p + 1] = (byte)Math.Clamp(y * 180 / size.Height + random.Next(0, 40), 0, 255);
            bytes[p + 2] = (byte)Math.Clamp(x * 180 / size.Width + random.Next(0, 40), 0, 255);
            bytes[p + 3] = 255;
        }
        var pixels = bitmap.LockBits(new Rectangle(Point.Empty, size), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try { Marshal.Copy(bytes, 0, pixels.Scan0, bytes.Length); }
        finally { bitmap.UnlockBits(pixels); }
    }
    else if (scene == "code")
    {
        graphics.Clear(Color.FromArgb(25, 30, 45));
        using var font = new Font("Consolas", 18);
        for (int y = 0; y < size.Height; y += 32)
        {
            using var brush = new SolidBrush(y % 3 == 0 ? Color.LightGreen : Color.WhiteSmoke);
            graphics.DrawString($"{y / 32 + 1:000}  async Task SendFrame_{y}() {{ await socket.SendAsync(packet); }} // 0123456789", font, brush, 12, y);
        }
    }
    else
    {
        graphics.FillRectangle(Brushes.Navy, 0, 0, size.Width, size.Height / 6);
        using var title = new Font("Segoe UI", size.Height / 28f, FontStyle.Bold);
        using var font = new Font("Segoe UI", size.Height / 40f);
        graphics.DrawString("Screen sharing — a synthetic slide", title, Brushes.White, 35, size.Height / 22);
        for (int i = 0; i < 5; i++)
            graphics.DrawString($"• Topic {i + 1}: readable text and diagrams", font, Brushes.Black, 40, size.Height / 4 + i * size.Height / 10);
        graphics.FillEllipse(Brushes.CornflowerBlue, size.Width * 3 / 4, size.Height / 3, size.Width / 7, size.Height / 3);
    }
    return bitmap;
}

sealed class Measurement
{
    public List<double> Times = new();
    public long Allocations;
    public double CpuMs;
    public int Bytes;
}

sealed class SinkSocket(int bandwidthMbps = 0) : WebSocket
{
    public byte[] Packet = [];
    public override WebSocketCloseStatus? CloseStatus => null;
    public override string? CloseStatusDescription => null;
    public override WebSocketState State => WebSocketState.Open;
    public override string? SubProtocol => null;
    public override void Abort() { }
    public override void Dispose() { }
    public override Task CloseAsync(WebSocketCloseStatus s, string? d, CancellationToken t) => Task.CompletedTask;
    public override Task CloseOutputAsync(WebSocketCloseStatus s, string? d, CancellationToken t) => Task.CompletedTask;
    public override Task<WebSocketReceiveResult> ReceiveAsync(ArraySegment<byte> b, CancellationToken t) => throw new NotSupportedException();
    public override Task SendAsync(ArraySegment<byte> data, WebSocketMessageType type, bool end, CancellationToken token)
    {
        Packet = data.Array ?? [];
        return bandwidthMbps == 0 ? Task.CompletedTask : Task.Delay(TimeSpan.FromSeconds(data.Count * 8.0 / (bandwidthMbps * 1_000_000)), token);
    }
}
